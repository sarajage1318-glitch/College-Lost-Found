from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    session
)

import os
import uuid

from werkzeug.utils import secure_filename

from config import Config
from utils.db import get_db, close_db

from werkzeug.security import (
    generate_password_hash,
    check_password_hash
)

from mysql.connector import IntegrityError


# =========================================================
# FLASK APP CONFIGURATION
# =========================================================

app = Flask(__name__)
app.config.from_object(Config)

# Photo upload settings
UPLOAD_FOLDER = os.path.join(app.root_path, "static", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
MAX_UPLOAD_SIZE = 5 * 1024 * 1024
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_SIZE

app.teardown_appcontext(close_db)


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


def save_uploaded_photo(file):
    if not file or not file.filename:
        return None

    if not allowed_file(file.filename):
        raise ValueError("Please upload a PNG, JPG, JPEG or WEBP image.")

    extension = secure_filename(file.filename).rsplit(".", 1)[1].lower()
    filename = f"{uuid.uuid4().hex}.{extension}"
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))
    return f"uploads/{filename}"


def find_matching_lost_item(cursor, item_name, category):
    """Find the newest active lost report for the same item/category."""
    cursor.execute(
        """
        SELECT item_id
        FROM items
        WHERE item_type = 'Lost'
          AND status = 'Lost'
          AND LOWER(TRIM(item_name)) = LOWER(TRIM(%s))
          AND LOWER(TRIM(category)) = LOWER(TRIM(%s))
        ORDER BY item_id DESC
        LIMIT 1
        """,
        (item_name, category)
    )
    match = cursor.fetchone()
    return match[0] if match else None


def find_matching_found_item(cursor, item_name, category):
    """Find the newest active found report for the same item/category."""
    cursor.execute(
        """
        SELECT item_id
        FROM items
        WHERE item_type = 'Found'
          AND status = 'Found'
          AND LOWER(TRIM(item_name)) = LOWER(TRIM(%s))
          AND LOWER(TRIM(category)) = LOWER(TRIM(%s))
        ORDER BY item_id DESC
        LIMIT 1
        """,
        (item_name, category)
    )
    match = cursor.fetchone()
    return match[0] if match else None


# =========================================================
# HOME
# =========================================================

@app.route("/")
def home():

    return render_template("index.html")


# =========================================================
# REGISTER
# =========================================================

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")

        if not name or not email or not phone or not password:

            flash(
                "Please fill in all required fields.",
                "error"
            )

            return redirect(
                url_for("register")
            )

        hashed_password = generate_password_hash(password)

        db = get_db()

        cursor = db.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO users
                (name, email, phone, password, role)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (
                    name,
                    email,
                    phone,
                    hashed_password,
                    "student"
                )
            )

            db.commit()

            flash(
                "Registration successful. Please log in.",
                "success"
            )

            return redirect(
                url_for("login")
            )

        except IntegrityError:

            db.rollback()

            flash(
                "Email already registered.",
                "error"
            )

            return redirect(
                url_for("register")
            )

        finally:

            cursor.close()

    return render_template("register.html")


# =========================================================
# LOGIN
# =========================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        db = get_db()

        cursor = db.cursor(
            dictionary=True
        )

        cursor.execute(
            """
            SELECT
                user_id,
                name,
                email,
                password,
                role
            FROM users
            WHERE email = %s
            """,
            (email,)
        )

        user = cursor.fetchone()

        cursor.close()

        if user:

            try:

                password_valid = check_password_hash(
                    user["password"],
                    password
                )

            except ValueError:

                password_valid = False

            if password_valid:

                session.clear()

                session["user_id"] = user["user_id"]
                session["user_name"] = user["name"]
                session["role"] = user["role"]

                flash(
                    "Login successful.",
                    "success"
                )

                if user["role"] == "admin":

                    return redirect(
                        url_for("admin_dashboard")
                    )

                return redirect(
                    url_for("dashboard")
                )

        flash(
            "Invalid email or password.",
            "error"
        )

    return render_template("login.html")


# =========================================================
# LOGOUT
# =========================================================

@app.route("/logout")
def logout():

    session.clear()

    flash(
        "You have been logged out.",
        "success"
    )

    return redirect(
        url_for("home")
    )


# =========================================================
# REPORT LOST ITEM
# =========================================================

@app.route(
    "/report-lost",
    methods=["GET", "POST"]
)
def report_lost():

    if "user_id" not in session:

        flash(
            "Please log in first.",
            "error"
        )

        return redirect(
            url_for("login")
        )

    db = get_db()
    user_cursor = db.cursor(dictionary=True)
    user_cursor.execute(
        "SELECT name, email, phone FROM users WHERE user_id = %s",
        (session["user_id"],)
    )
    current_user = user_cursor.fetchone()
    user_cursor.close()

    if request.method == "POST":

        item_name = request.form.get(
            "item_name",
            ""
        ).strip()

        category = request.form.get(
            "category",
            ""
        ).strip()

        description = request.form.get(
            "description",
            ""
        ).strip()

        location = request.form.get(
            "location",
            ""
        ).strip()

        date_reported = request.form.get(
            "date_reported",
            ""
        )

        try:
            image_path = save_uploaded_photo(request.files.get("photo"))
        except ValueError as exc:
            flash(str(exc), "error")
            return redirect(url_for("report_lost"))

        if not item_name or not category or not location or not date_reported:

            flash(
                "Please fill in all required fields.",
                "error"
            )

            return redirect(
                url_for("report_lost")
            )

        db = get_db()

        cursor = db.cursor()

        cursor.execute(
            """
            INSERT INTO items
            (
                item_name,
                category,
                description,
                item_type,
                location,
                date_reported,
                reported_by,
                image_path,
                status
            )
            VALUES
            (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                item_name,
                category,
                description,
                "Lost",
                location,
                date_reported,
                session["user_id"],
                image_path,
                "Lost"
            )
        )

        lost_item_id = cursor.lastrowid

        # Link to an already-reported Found item, if one exists.
        matching_found_id = find_matching_found_item(cursor, item_name, category)
        if matching_found_id:
            cursor.execute(
                """
                UPDATE items
                SET status = 'Matched', matched_item_id = %s
                WHERE item_id = %s
                """,
                (matching_found_id, lost_item_id)
            )
            cursor.execute(
                """
                UPDATE items
                SET matched_item_id = %s
                WHERE item_id = %s
                """,
                (lost_item_id, matching_found_id)
            )

        db.commit()

        cursor.close()

        if matching_found_id:
            flash(
                "Lost item reported and linked to an existing matching found report. You can open the match from your dashboard.",
                "success"
            )
        else:
            flash(
                "Lost item reported successfully.",
                "success"
            )

        return redirect(
            url_for("items")
        )

    return render_template(
        "report-lost.html",
        current_user=current_user
    )


# =========================================================
# REPORT FOUND ITEM
# =========================================================

@app.route(
    "/report-found",
    methods=["GET", "POST"]
)
def report_found():

    if "user_id" not in session:

        flash(
            "Please log in first.",
            "error"
        )

        return redirect(
            url_for("login")
        )

    db = get_db()
    user_cursor = db.cursor(dictionary=True)
    user_cursor.execute(
        "SELECT name, email, phone FROM users WHERE user_id = %s",
        (session["user_id"],)
    )
    current_user = user_cursor.fetchone()
    user_cursor.close()

    if request.method == "POST":

        item_name = request.form.get(
            "item_name",
            ""
        ).strip()

        category = request.form.get(
            "category",
            ""
        ).strip()

        description = request.form.get(
            "description",
            ""
        ).strip()

        location = request.form.get(
            "location",
            ""
        ).strip()

        date_reported = request.form.get(
            "date_reported",
            ""
        )

        try:
            image_path = save_uploaded_photo(request.files.get("photo"))
        except ValueError as exc:
            flash(str(exc), "error")
            return redirect(url_for("report_found"))

        if not item_name or not category or not location or not date_reported:

            flash(
                "Please fill in all required fields.",
                "error"
            )

            return redirect(
                url_for("report_found")
            )

        db = get_db()

        cursor = db.cursor()

        cursor.execute(
            """
            INSERT INTO items
            (
                item_name,
                category,
                description,
                item_type,
                location,
                date_reported,
                reported_by,
                image_path,
                status
            )
            VALUES
            (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                item_name,
                category,
                description,
                "Found",
                location,
                date_reported,
                session["user_id"],
                image_path,
                "Found"
            )
        )

        found_item_id = cursor.lastrowid

        # Link a found report to the newest matching lost report.
        matching_lost_id = find_matching_lost_item(cursor, item_name, category)
        if matching_lost_id:
            cursor.execute(
                """
                UPDATE items
                SET status = 'Matched', matched_item_id = %s
                WHERE item_id = %s
                """,
                (found_item_id, matching_lost_id)
            )
            cursor.execute(
                """
                UPDATE items
                SET matched_item_id = %s
                WHERE item_id = %s
                """,
                (matching_lost_id, found_item_id)
            )

        db.commit()

        cursor.close()

        if matching_lost_id:
            flash(
                "Found item reported and linked to a matching lost report. The lost report is now hidden from public Browse.",
                "success"
            )
        else:
            flash(
                "Found item reported successfully.",
                "success"
            )

        return redirect(
            url_for("items")
        )

    return render_template(
        "report-found.html",
        current_user=current_user
    )


# =========================================================
# BROWSE ITEMS
# =========================================================

@app.route("/items")
def items():

    search = request.args.get("search", "").strip()
    category = request.args.get("category", "").strip()
    view = request.args.get("view", "lost").strip().lower()

    # Keep older links using ?item_type=... working.
    legacy_type = request.args.get("item_type", "").strip().lower()
    if legacy_type in ("lost", "found"):
        view = legacy_type

    if view not in ("lost", "found"):
        view = "lost"

    selected_type = "Lost" if view == "lost" else "Found"

    db = get_db()
    cursor = db.cursor(dictionary=True)

    # Public browsing contains only currently available records.
    # Claim Pending / Claim Approved / Returned records are excluded.
    query = """
        SELECT
            i.item_id,
            i.item_name,
            i.category,
            i.description,
            i.item_type,
            i.location,
            i.date_reported,
            i.reported_by,
            i.image_path,
            i.status,
            i.matched_item_id,
            u.name AS reporter_name
        FROM items i
        JOIN users u ON i.reported_by = u.user_id
        WHERE i.status = %s
    """

    params = [selected_type]

    if search:
        query += """
            AND (
                LOWER(COALESCE(item_name, '')) LIKE LOWER(%s)
                OR LOWER(COALESCE(description, '')) LIKE LOWER(%s)
                OR LOWER(COALESCE(location, '')) LIKE LOWER(%s)
                OR LOWER(COALESCE(category, '')) LIKE LOWER(%s)
            )
        """
        search_value = f"%{search}%"
        params.extend([search_value] * 4)

    if category:
        query += " AND category = %s "
        params.append(category)

    query += " ORDER BY item_id DESC "

    cursor.execute(query, params)
    items_list = cursor.fetchall()

    # Counts show how many currently available records exist in each section.
    cursor.execute("SELECT COUNT(*) AS total FROM items WHERE status = 'Lost'")
    lost_count = cursor.fetchone()["total"]

    cursor.execute("SELECT COUNT(*) AS total FROM items WHERE status = 'Found'")
    found_count = cursor.fetchone()["total"]

    # Add matched Lost/Found report details for the Browse page.
    for row in items_list:
        row["matched_item"] = None
        if row.get("matched_item_id"):
            cursor.execute(
                """
                SELECT i.item_id, i.item_name, i.item_type, i.status,
                       i.reported_by, u.name AS reporter_name
                FROM items i
                JOIN users u ON i.reported_by = u.user_id
                WHERE i.item_id = %s
                """,
                (row["matched_item_id"],)
            )
            row["matched_item"] = cursor.fetchone()

    # Logged-in user's own details, always read from the session's user_id
    # (never from the URL) so each student only sees their own information.
    current_user = None
    if session.get("user_id"):
        cursor.execute(
            "SELECT user_id, name, email, phone FROM users WHERE user_id = %s",
            (session["user_id"],)
        )
        current_user = cursor.fetchone()

    cursor.close()

    return render_template(
        "items.html",
        current_user=current_user,
        items=items_list,
        search=search,
        selected_category=category,
        selected_type=selected_type,
        view=view,
        lost_count=lost_count,
        found_count=found_count
    )


# =========================================================
# ITEM DETAILS
# =========================================================

@app.route("/item/<int:item_id>")
def item_details(item_id):

    db = get_db()

    cursor = db.cursor(
        dictionary=True
    )

    cursor.execute(
        """
        SELECT
            i.*,
            u.name AS reporter_name,
            u.email AS reporter_email,
            u.phone AS reporter_phone
        FROM items i
        JOIN users u ON i.reported_by = u.user_id
        WHERE i.item_id = %s
        """,
        (item_id,)
    )

    item = cursor.fetchone()

    if item:
        cursor.execute(
            """
            SELECT item_id, item_name, category, location, image_path, status
            FROM items
            WHERE item_id = %s
            """,
            (item.get("matched_item_id"),)
        ) if item.get("matched_item_id") else None
        item["matched_item"] = cursor.fetchone() if item.get("matched_item_id") else None

    cursor.close()

    if not item:

        flash(
            "Item not found.",
            "error"
        )

        return redirect(
            url_for("items")
        )

    # Public users can only view items that are currently available
    # in the Browse Items page. Admins can still open all item records.
    # A student may still open their own matched lost report from the dashboard.
    if session.get("role") != "admin" and item["status"] not in ("Lost", "Found"):
        if not (item["item_type"] == "Lost" and item["reported_by"] == session.get("user_id") and item["status"] == "Matched"):
            flash("This item is no longer available in Browse Items.", "error")
            return redirect(url_for("items"))

    can_claim = False
    if session.get("user_id") and item["item_type"] == "Found" and item["status"] == "Found":
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT item_id FROM items
            WHERE reported_by = %s AND item_type = 'Lost'
              AND LOWER(TRIM(item_name)) = LOWER(TRIM(%s))
              AND LOWER(TRIM(category)) = LOWER(TRIM(%s))
              AND status IN ('Lost', 'Matched')
            LIMIT 1
            """,
            (session["user_id"], item["item_name"], item["category"])
        )
        can_claim = cursor.fetchone() is not None
        cursor.close()

    return render_template(
        "item.html",
        item=item,
        can_claim=can_claim
    )


# =========================================================
# CLAIM ITEM
# =========================================================

@app.route(
    "/claim/<int:item_id>",
    methods=["GET", "POST"]
)
def claim_item(item_id):

    if "user_id" not in session:
        flash("Please log in first.", "error")
        return redirect(url_for("login"))

    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute(
        """
        SELECT
            i.item_id, i.item_name, i.category, i.location, i.image_path,
            i.status, i.matched_item_id,
            u.name AS finder_name, u.email AS finder_email, u.phone AS finder_phone
        FROM items i
        JOIN users u ON i.reported_by = u.user_id
        WHERE i.item_id = %s AND i.item_type = 'Found'
        """,
        (item_id,)
    )
    item = cursor.fetchone()

    if not item or item["status"] != "Found":
        cursor.close()
        flash("This found item is no longer available for a claim.", "error")
        return redirect(url_for("items", view="found"))

    # A claim is allowed only when this student has a matching lost report.
    cursor.execute(
        """
        SELECT item_id, item_name, location
        FROM items
        WHERE reported_by = %s
          AND item_type = 'Lost'
          AND LOWER(TRIM(item_name)) = LOWER(TRIM(%s))
          AND LOWER(TRIM(category)) = LOWER(TRIM(%s))
          AND status IN ('Lost', 'Matched')
        ORDER BY item_id DESC
        LIMIT 1
        """,
        (session["user_id"], item["item_name"], item["category"])
    )
    owner_lost = cursor.fetchone()

    if not owner_lost:
        cursor.close()
        flash("To claim this item, first report your lost item with the matching item name and category.", "error")
        return redirect(url_for("item_details", item_id=item_id))

    if request.method == "POST":
        reason = request.form.get("reason", "").strip()

        try:
            proof_path = save_uploaded_photo(request.files.get("proof_photo"))
        except ValueError as exc:
            cursor.close()
            flash(str(exc), "error")
            return redirect(url_for("claim_item", item_id=item_id))

        if not reason:
            cursor.close()
            flash("Please provide a reason for your claim.", "error")
            return redirect(url_for("claim_item", item_id=item_id))

        cursor.execute(
            """
            SELECT request_id
            FROM claim_requests
            WHERE item_id = %s AND student_id = %s
              AND status IN ('Contacted', 'Resolved')
            """,
            (item_id, session["user_id"])
        )
        if cursor.fetchone():
            cursor.close()
            flash("You have already contacted the finder for this item.", "error")
            return redirect(url_for("dashboard"))

        cursor.execute(
            """
            INSERT INTO claim_requests
            (item_id, student_id, reason, proof, request_date, status)
            VALUES (%s, %s, %s, %s, CURDATE(), 'Contacted')
            """,
            (item_id, session["user_id"], reason, proof_path)
        )

        # The found item is now being handled privately and is removed from Browse.
        cursor.execute(
            """
            UPDATE items
            SET status = 'Contacted', matched_item_id = %s
            WHERE item_id = %s
            """,
            (owner_lost["item_id"], item_id)
        )

        db.commit()
        cursor.close()

        flash(
            "Connection request sent. The finder's contact details are now available in your dashboard so you can contact each other directly.",
            "success"
        )
        return redirect(url_for("dashboard"))

    cursor.close()
    return render_template("claim.html", item=item, owner_lost=owner_lost)


# =========================================================
# STUDENT DASHBOARD
# =========================================================

@app.route("/dashboard")
def dashboard():

    if "user_id" not in session:
        flash("Please log in first.", "error")
        return redirect(url_for("login"))

    db = get_db()
    cursor = db.cursor(dictionary=True)
    user_id = session["user_id"]

    # -----------------------------------------------------
    # MY LOST ITEMS
    # -----------------------------------------------------
    cursor.execute(
        """
        SELECT
            item_id, item_name, category, description,
            item_type, location, date_reported, image_path,
            status, matched_item_id
        FROM items
        WHERE reported_by = %s
          AND item_type = 'Lost'
        ORDER BY item_id DESC
        """,
        (user_id,)
    )
    my_items = cursor.fetchall()

    # -----------------------------------------------------
    # OWNER SIDE CONNECTIONS
    # Owner = person who reported the Lost item.
    # Finder = person who reported the matching Found item.
    # -----------------------------------------------------
    cursor.execute(
        """
        SELECT
            c.request_id,
            c.item_id,
            c.student_id,
            c.reason,
            c.proof,
            c.request_date,
            c.status,
            found.item_name,
            found.category,
            found.location,
            found.image_path,
            finder.name AS finder_name,
            finder.email AS finder_email,
            finder.phone AS finder_phone
        FROM claim_requests c
        JOIN items found
            ON c.item_id = found.item_id
        JOIN items lost
            ON found.matched_item_id = lost.item_id
        JOIN users finder
            ON found.reported_by = finder.user_id
        WHERE lost.reported_by = %s
          AND lost.item_type = 'Lost'
        ORDER BY c.request_id DESC
        """,
        (user_id,)
    )
    my_connections = cursor.fetchall()

    # -----------------------------------------------------
    # FINDER SIDE CONNECTIONS
    # Finder = person who reported the Found item.
    # Owner = person who reported the matching Lost item.
    # IMPORTANT: owner is resolved through matched_item_id,
    # not claim_requests.student_id.
    # -----------------------------------------------------
    cursor.execute(
        """
        SELECT
            c.request_id,
            c.item_id,
            c.student_id,
            c.reason,
            c.proof,
            c.request_date,
            c.status,
            found.item_name,
            found.category,
            found.location,
            found.image_path,
            owner.name AS owner_name,
            owner.email AS owner_email,
            owner.phone AS owner_phone
        FROM claim_requests c
        JOIN items found
            ON c.item_id = found.item_id
        JOIN items lost
            ON found.matched_item_id = lost.item_id
        JOIN users owner
            ON lost.reported_by = owner.user_id
        WHERE found.reported_by = %s
          AND found.item_type = 'Found'
        ORDER BY c.request_id DESC
        """,
        (user_id,)
    )
    finder_connections = cursor.fetchall()

    # -----------------------------------------------------
    # POSSIBLE MATCHES FOR MY LOST ITEMS
    # Only currently public/unmatched Found records count.
    # -----------------------------------------------------
    for lost in my_items:
        cursor.execute(
            """
            SELECT
                item_id, item_name, category, location,
                image_path, status
            FROM items
            WHERE item_type = 'Found'
              AND status = 'Found'
              AND matched_item_id IS NULL
              AND LOWER(TRIM(item_name)) = LOWER(TRIM(%s))
              AND LOWER(TRIM(category)) = LOWER(TRIM(%s))
            ORDER BY item_id DESC
            LIMIT 1
            """,
            (lost["item_name"], lost["category"])
        )
        lost["possible_match"] = cursor.fetchone()

    cursor.close()

    return render_template(
        "dashboard.html",
        my_items=my_items,
        my_connections=my_connections,
        finder_connections=finder_connections
    )


# =========================================================
# ADMIN DASHBOARD
# =========================================================

@app.route("/admin")
def admin_dashboard():

    # Check login

    if "user_id" not in session:

        flash(
            "Please log in first.",
            "error"
        )

        return redirect(
            url_for("login")
        )

    # Check admin role

    if session.get("role") != "admin":

        flash(
            "Administrator access is required.",
            "error"
        )

        return redirect(
            url_for("home")
        )

    db = get_db()

    cursor = db.cursor(
        dictionary=True
    )


    # -----------------------------------------------------
    # ALL REPORTED ITEMS
    # -----------------------------------------------------

    cursor.execute(
        """
        SELECT
            i.item_id,
            i.item_name,
            i.category,
            i.item_type,
            i.location,
            i.date_reported,
            i.image_path,
            i.status,
            u.name AS reporter_name,
            u.email AS reporter_email,
            u.phone AS reporter_phone
        FROM items i
        JOIN users u
            ON i.reported_by = u.user_id
        ORDER BY i.item_id DESC
        """
    )

    all_items = cursor.fetchall()


    # -----------------------------------------------------
    # ALL CLAIM REQUESTS
    # -----------------------------------------------------

    cursor.execute(
        """
        SELECT
            c.request_id,
            c.item_id,
            c.student_id,
            c.reason,
            c.proof,
            c.request_date,
            c.status,

            i.item_name,

            u.name AS student_name,
            u.email AS student_email,
            u.phone AS student_phone

        FROM claim_requests c

        JOIN items i
            ON c.item_id = i.item_id

        JOIN users u
            ON c.student_id = u.user_id

        ORDER BY c.request_id DESC
        """
    )

    claims = cursor.fetchall()

    cursor.close()

    return render_template(
        "admin.html",
        all_items=all_items,
        claims=claims
    )



# =========================================================
# APPROVE / REJECT ITEM REPORT
# =========================================================

@app.route("/admin/item/<int:item_id>/approve-report", methods=["POST"])
def approve_item_report(item_id):
    if session.get("role") != "admin":
        flash("Administrator access required.", "error")
        return redirect(url_for("login"))

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT item_type FROM items WHERE item_id = %s", (item_id,))
    row = cursor.fetchone()
    if not row:
        cursor.close()
        flash("Item report not found.", "error")
        return redirect(url_for("admin_dashboard"))

    cursor.execute("UPDATE items SET status = %s WHERE item_id = %s", (row[0], item_id))
    db.commit()
    cursor.close()
    flash("Item report approved successfully.", "success")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/item/<int:item_id>/reject-report", methods=["POST"])
def reject_item_report(item_id):
    if session.get("role") != "admin":
        flash("Administrator access required.", "error")
        return redirect(url_for("login"))

    db = get_db()
    cursor = db.cursor()
    cursor.execute(
        "UPDATE items SET status = 'Rejected' WHERE item_id = %s AND item_type IN ('Lost', 'Found')",
        (item_id,)
    )
    db.commit()
    cursor.close()
    flash("Item report rejected.", "success")
    return redirect(url_for("admin_dashboard"))


# =========================================================
# APPROVE CLAIM
# =========================================================

@app.route(
    "/admin/claim/<int:request_id>/approve",
    methods=["POST"]
)
def approve_claim(request_id):

    if session.get("role") != "admin":
        flash("Administrator access required.", "error")
        return redirect(url_for("login"))

    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute(
        "SELECT item_id, status FROM claim_requests WHERE request_id = %s",
        (request_id,)
    )
    claim = cursor.fetchone()

    if not claim:
        cursor.close()
        flash("Claim request not found.", "error")
        return redirect(url_for("admin_dashboard"))

    cursor.execute(
        "UPDATE claim_requests SET status = 'Approved' WHERE request_id = %s",
        (request_id,)
    )
    cursor.execute(
        "UPDATE items SET status = 'Claim Approved' WHERE item_id = %s",
        (claim["item_id"],)
    )

    db.commit()
    cursor.close()

    flash("Claim approved successfully. The item can now be marked as returned.", "success")
    return redirect(url_for("admin_dashboard"))


# =========================================================
# REJECT CLAIM
# =========================================================

@app.route(
    "/admin/claim/<int:request_id>/reject",
    methods=["POST"]
)
def reject_claim(request_id):

    if session.get("role") != "admin":
        flash("Administrator access required.", "error")
        return redirect(url_for("login"))

    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute(
        "SELECT item_id FROM claim_requests WHERE request_id = %s",
        (request_id,)
    )
    claim = cursor.fetchone()

    if not claim:
        cursor.close()
        flash("Claim request not found.", "error")
        return redirect(url_for("admin_dashboard"))

    cursor.execute(
        "UPDATE claim_requests SET status = 'Rejected' WHERE request_id = %s",
        (request_id,)
    )
    cursor.execute(
        "UPDATE items SET status = 'Found' WHERE item_id = %s",
        (claim["item_id"],)
    )

    db.commit()
    cursor.close()

    flash("Claim rejected. The found item is available again.", "success")
    return redirect(url_for("admin_dashboard"))


# =========================================================
# MARK ITEM AS RETURNED
# =========================================================

@app.route(
    "/admin/item/<int:item_id>/returned",
    methods=["POST"]
)
def mark_returned(item_id):

    if session.get("role") != "admin":

        flash(
            "Administrator access required.",
            "error"
        )

        return redirect(
            url_for("login")
        )

    db = get_db()

    cursor = db.cursor()

    cursor.execute(
        """
        UPDATE items
        SET status = 'Returned'
        WHERE item_id = %s
        """,
        (item_id,)
    )

    db.commit()

    cursor.close()

    flash(
        "Item marked as returned.",
        "success"
    )

    return redirect(
        url_for("admin_dashboard")
    )


# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":

    app.run(debug=False)