# College Lost & Found Portal

A Flask + MySQL web application for reporting lost/found college items and managing item claim requests.

## Technologies
- HTML, CSS, Bootstrap, JavaScript
- Python + Flask
- MySQL
- Jinja2 templates

## Main features
- Student registration/login with contact number
- Separate Report Lost and Report Found pages
- Optional item photo upload (PNG/JPG/JPEG/WEBP, max 5 MB)
- Lost and Found browsing sections with search and category filtering
- Case-insensitive search across item name, description, location and category
- Student dashboard showing only the student's Lost item reports
- Claim request submission and tracking
- Admin dashboard with Lost and Found reports, reporter contact details and claim management
- Approving a claim removes the item from public browsing while retaining the database record for admin tracking
- Multiple pending claims are handled automatically when one claim is approved

## Database
Database name: `college_lost_found`

Required tables:
- `users`
- `items`
- `claim_requests`

Run `database_update.sql` once on an existing database to add the `users.phone` field if it is not already present.

## Run locally
1. Start MySQL.
2. Ensure the database and tables exist.
3. Set the MySQL password as an environment variable named `MYSQL_PASSWORD`.
4. Open a terminal in this folder.
5. Install dependencies:
   `pip install -r requirements.txt`
6. Start the application:
   `python app.py`
7. Open the local Flask URL shown in the terminal, normally `http://127.0.0.1:5000`.


## Final connection workflow
- Lost and Found reports can be linked when item name and category match.
- A matching Lost report is marked Matched and hidden from public Browse.
- Only a Found item can receive a connection/claim request.
- A student can connect to a Found report only when they have a matching Lost report under their account.
- The connection request supports an uploaded proof photo.
- No administrator approval is required for the connection. Finder contact details are shown to the claimant after submission.
- Connected Found items are removed from public Browse while their database records remain for history.
