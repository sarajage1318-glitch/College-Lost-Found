USE college_lost_found;

-- New field required for reporter contact details.
ALTER TABLE users
ADD COLUMN IF NOT EXISTS phone VARCHAR(20) NULL AFTER email;

-- image_path already exists in the current items table,
-- so no change is required for photo storage.

-- For existing users, add their contact number manually, for example:
-- UPDATE users SET phone = 'YOUR_CONTACT_NUMBER' WHERE email = 'YOUR_EMAIL';


-- Add the link between a Lost report and its matching Found report.
ALTER TABLE items ADD COLUMN matched_item_id INT NULL;
ALTER TABLE items ADD CONSTRAINT fk_items_matched_item
    FOREIGN KEY (matched_item_id) REFERENCES items(item_id);
