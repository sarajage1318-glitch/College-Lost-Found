CREATE DATABASE IF NOT EXISTS college_lost_found;
USE college_lost_found;

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'student'
);

CREATE TABLE IF NOT EXISTS items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT,
    item_type VARCHAR(10) NOT NULL,
    location VARCHAR(150) NOT NULL,
    date_reported DATE NOT NULL,
    reported_by INT NOT NULL,
    image_path VARCHAR(255),
    status VARCHAR(30) DEFAULT 'Lost',
    matched_item_id INT NULL,
    FOREIGN KEY (reported_by) REFERENCES users(user_id),
    FOREIGN KEY (matched_item_id) REFERENCES items(item_id)
);

CREATE TABLE IF NOT EXISTS claim_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    student_id INT NOT NULL,
    reason TEXT NOT NULL,
    proof VARCHAR(255),
    request_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'Pending',
    FOREIGN KEY (item_id) REFERENCES items(item_id),
    FOREIGN KEY (student_id) REFERENCES users(user_id)
);
